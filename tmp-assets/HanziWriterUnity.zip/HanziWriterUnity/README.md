# Hanzi Writer Demo — Setup Instructions

Target: Unity **6000.3.19f1**, Universal 2D template. No extra packages required.

## What's in here

```
Assets/
  Scripts/
    CharacterStrokeData.cs          - ScriptableObject: one character's stroke data
    CharacterValidationSettings.cs  - ScriptableObject: tunable scoring thresholds
    StrokeValidator.cs              - resample + DTW comparison (the verification algorithm)
    CharacterDatabase.cs            - loads CharacterStrokeData by character at runtime
    DemoCharacterData.cs            - hardcoded fallback data for 一, 十, 人
    StrokeInputRecorder.cs          - captures mouse strokes           (scene component)
    StrokeRenderer.cs               - draws guides + player's line     (scene component)
    CharacterWritingSession.cs      - practice-mode state machine      (scene component)
    CharacterWritingUI.cs           - on-screen status text/buttons    (scene component)
  Editor/
    HanziStrokeImporter.cs          - Tools > Hanzi Writer > Import Characters From JSON...
    SampleCharacterCreator.cs       - Tools > Hanzi Writer > Create Sample Characters
    HanziSceneBuilder.cs            - Tools > Hanzi Writer > Build Demo Scene In Current Scene
  Scenes/
    HanziWriterDemo.unity           - hand-authored scene, ready to open and press Play
  SampleData/
    sample_characters.json          - example input for HanziStrokeImporter
```

## Step 1 — copy files in

Copy the contents of this `Assets/` folder into your Unity project's own `Assets/` folder (merging with your existing `Scripts`/`Editor` folders if you have them). Let Unity finish compiling.

## Step 2 — open the scene

Open `Assets/Scenes/HanziWriterDemo.unity` and press **Play**. You should see:
- a black square outline (the drawing area)
- a faint gray guide stroke inside it
- status text top-left ("Character: 十  Stroke 1 / 2 ...")

Draw with the mouse inside the square, following the gray guide. Correct strokes flash green and the next guide stroke lights up blue; incorrect attempts flash red and you retry the same stroke.

### If the scene doesn't open cleanly

The `.unity` file was hand-written as plain text rather than exported from a real Editor session, so there's a small chance a Unity-version quirk trips it up. If that happens, it's a two-second fix — this is the **guaranteed-to-work** fallback:

1. Create a new empty scene (`File > New Scene` → Basic (URP) or Empty).
2. Run **Tools > Hanzi Writer > Build Demo Scene In Current Scene**.
3. Press Play.

This menu command builds the identical Main Camera + GameController setup purely through Unity's own APIs, so it can't have a serialization mismatch.

## Step 3 (optional) — persist sample characters as real assets

Run **Tools > Hanzi Writer > Create Sample Characters (十, 一, 人)**. This saves three `CharacterStrokeData` assets under `Assets/Resources/CharacterData/`. Not required for the demo to run (it falls back to the same data in-memory), but useful to see what an imported character actually looks like as an asset.

## Step 4 — bring in real characters later

When you have a licensed stroke-order dataset (see the design doc, §2.1, for what to look for and license caveats), convert it into the JSON schema shown in `SampleData/sample_characters.json`, then run **Tools > Hanzi Writer > Import Characters From JSON...** and pick the file. This works for one character or thousands — it's the same reapplyable pipeline described in the design doc.

## Important: Input System setting

These scripts use the legacy `Input.mousePosition` / `Input.GetMouseButton` API. If your project's **Player Settings > Active Input Handling** is set to *"Input System Package (New)"* only, switch it to **"Both"** (Edit > Project Settings > Player), or the drawing input won't register at all.

## Tuning difficulty

Everything the validator checks — shape tolerance, allowed length ratio, allowed position drift — lives in `CharacterValidationSettings`. Create one via `Assets > Create > HanziWriting > Validation Settings`, tweak the values, and assign it to the `Settings` field on the `CharacterWritingSession` component (or leave it unassigned — the session creates a default one automatically).

## Known limitations of this build

- Only Practice Mode (one guided stroke at a time) is implemented. Assessment Mode (freeform, whole-character alignment) was flagged as a stretch goal in the design doc and isn't built here.
- Only 3 demo characters (一, 十, 人) ship with real stroke data — everything else depends on you sourcing/importing a real dataset (see Step 4).
- UI is intentionally bare-bones IMGUI (`OnGUI`), not a styled Canvas — swap in your own UI once the core loop is confirmed working.
