using UnityEngine;

/// <summary>
/// Tunable thresholds for stroke verification. Keeping these as data (rather
/// than hardcoded constants) means difficulty can be adjusted per game mode
/// or age group without touching StrokeValidator's code.
/// </summary>
[CreateAssetMenu(menuName = "HanziWriting/Validation Settings")]
public class CharacterValidationSettings : ScriptableObject
{
    [Tooltip("Number of points both reference and player strokes are resampled to before comparison.")]
    public int resamplePointCount = 32;

    [Tooltip("Max average per-point DTW distance (normalized 0-1 units) to still count as a shape match. Lower = stricter.")]
    public float shapeTolerance = 0.09f;

    [Tooltip("Player stroke length must be at least this fraction of the reference stroke's length.")]
    public float minLengthRatio = 0.45f;

    [Tooltip("Player stroke length must be at most this multiple of the reference stroke's length.")]
    public float maxLengthRatio = 2.0f;

    [Tooltip("Max allowed centroid shift between player and reference stroke, normalized 0-1 units.")]
    public float positionTolerance = 0.14f;

    [Tooltip("Strokes with fewer recorded points than this are rejected as accidental clicks.")]
    public int minStrokePointCount = 3;

    [Tooltip("Strokes shorter than this (normalized units) are rejected as accidental clicks.")]
    public float minStrokeLength = 0.03f;
}
