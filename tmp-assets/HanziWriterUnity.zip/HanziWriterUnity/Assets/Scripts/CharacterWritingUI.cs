using UnityEngine;

/// <summary>
/// Deliberately uses IMGUI (OnGUI) instead of a Canvas/UI Text setup, so the
/// demo scene needs zero UI package configuration and zero font asset
/// references to just work.
/// </summary>
[RequireComponent(typeof(CharacterWritingSession))]
public class CharacterWritingUI : MonoBehaviour
{
    private CharacterWritingSession _session;
    private readonly string[] _demoCharacters = { "十", "一", "人" };

    void Awake()
    {
        _session = GetComponent<CharacterWritingSession>();
    }

    void OnGUI()
    {
        GUI.skin.label.fontSize = 18;
        GUI.skin.button.fontSize = 16;

        GUILayout.BeginArea(new Rect(10, 10, 460, 150));
        GUILayout.Label($"Character: {_session.targetCharacter}    Stroke {Mathf.Min(_session.CurrentStrokeIndex + 1, Mathf.Max(_session.TotalStrokes, 1))} / {_session.TotalStrokes}");
        GUILayout.Label(_session.StatusMessage);

        GUILayout.Space(6);
        GUILayout.Label("Try a different character:");
        GUILayout.BeginHorizontal();
        foreach (var ch in _demoCharacters)
        {
            if (GUILayout.Button(ch, GUILayout.Width(50), GUILayout.Height(36)))
                _session.LoadCharacter(ch);
        }
        GUILayout.EndHorizontal();
        GUILayout.EndArea();
    }
}
