using UnityEngine;

/// <summary>
/// Reference data for one character: an ordered list of strokes, each defined
/// by a "median" polyline (the centerline a pen would follow), normalized to
/// a 0..1 square. Created by hand (DemoCharacterData), by HanziStrokeImporter
/// (from a JSON source), or by any future importer — the runtime code never
/// needs to know which.
/// </summary>
[CreateAssetMenu(menuName = "HanziWriting/Character Stroke Data")]
public class CharacterStrokeData : ScriptableObject
{
    public string character;
    public int unicodeCodepoint;
    public StrokeData[] strokes;

    [Tooltip("\"dataset\" if sourced from a curated stroke-order dataset, \"generated\" if derived from a font glyph and not yet human-reviewed.")]
    public string sourceType = "generated";
}

[System.Serializable]
public class StrokeData
{
    [Tooltip("Ordered points along the stroke's centerline, normalized 0..1, in drawing direction (start point first).")]
    public Vector2[] medianPoints;
}
