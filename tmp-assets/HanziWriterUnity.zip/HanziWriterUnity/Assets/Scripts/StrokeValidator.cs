using System.Collections.Generic;
using UnityEngine;

public class StrokeResult
{
    public bool pass;
    public string message;
    public float dtwScore;
    public float lengthRatio;
    public float centroidShift;
}

/// <summary>
/// Pure, stateless comparison logic. Works identically for any character —
/// it only ever sees two point lists (reference stroke, player stroke) and a
/// settings object. Nothing here is character-specific.
/// </summary>
public static class StrokeValidator
{
    public static StrokeResult ValidateStroke(List<Vector2> rawUserPoints, StrokeData reference, CharacterValidationSettings settings)
    {
        var result = new StrokeResult();

        if (rawUserPoints == null || rawUserPoints.Count < settings.minStrokePointCount)
        {
            result.pass = false;
            result.message = "Stroke too short — try again.";
            return result;
        }

        float userLength = PathLength(rawUserPoints);
        if (userLength < settings.minStrokeLength)
        {
            result.pass = false;
            result.message = "Stroke too short — try again.";
            return result;
        }

        var refPoints = new List<Vector2>(reference.medianPoints);
        float refLength = PathLength(refPoints);

        Vector2[] a = Resample(refPoints, settings.resamplePointCount);
        Vector2[] b = Resample(rawUserPoints, settings.resamplePointCount);

        float dtw = DTWDistance(a, b);
        float lengthRatio = refLength > 0.0001f ? userLength / refLength : 1f;

        Vector2 centroidA = Centroid(a);
        Vector2 centroidB = Centroid(b);
        float centroidShift = Vector2.Distance(centroidA, centroidB);

        result.dtwScore = dtw;
        result.lengthRatio = lengthRatio;
        result.centroidShift = centroidShift;

        bool shapeOk = dtw <= settings.shapeTolerance;
        bool lengthOk = lengthRatio >= settings.minLengthRatio && lengthRatio <= settings.maxLengthRatio;
        bool posOk = centroidShift <= settings.positionTolerance;

        result.pass = shapeOk && lengthOk && posOk;

        if (!result.pass)
        {
            if (!shapeOk) result.message = "Shape doesn't match — try again.";
            else if (!lengthOk) result.message = lengthRatio < 1f ? "Stroke too short — try again." : "Stroke too long — try again.";
            else result.message = "Off position — try again.";
        }
        else
        {
            result.message = "Correct!";
        }

        return result;
    }

    /// <summary>Resample a polyline to exactly targetCount points, evenly spaced by arc length (not by index).</summary>
    public static Vector2[] Resample(List<Vector2> points, int targetCount)
    {
        var result = new Vector2[targetCount];
        if (points == null || points.Count == 0)
            return result;

        if (points.Count == 1)
        {
            for (int i = 0; i < targetCount; i++) result[i] = points[0];
            return result;
        }

        float totalLength = 0f;
        var cumLength = new float[points.Count];
        cumLength[0] = 0f;
        for (int i = 1; i < points.Count; i++)
        {
            totalLength += Vector2.Distance(points[i - 1], points[i]);
            cumLength[i] = totalLength;
        }

        if (totalLength <= 0.0001f)
        {
            for (int i = 0; i < targetCount; i++) result[i] = points[0];
            return result;
        }

        for (int i = 0; i < targetCount; i++)
        {
            float targetDist = totalLength * i / (targetCount - 1);
            int seg = 0;
            while (seg < cumLength.Length - 1 && cumLength[seg + 1] < targetDist) seg++;

            float segStart = cumLength[seg];
            float segEnd = (seg + 1 < cumLength.Length) ? cumLength[seg + 1] : segStart;
            float t = (segEnd - segStart) > 0.0001f ? (targetDist - segStart) / (segEnd - segStart) : 0f;

            Vector2 pa = points[seg];
            Vector2 pb = points[Mathf.Min(seg + 1, points.Count - 1)];
            result[i] = Vector2.Lerp(pa, pb, t);
        }

        return result;
    }

    /// <summary>Dynamic Time Warping distance between two equal-or-different-length point sequences, normalized by path length so it's comparable across strokes.</summary>
    public static float DTWDistance(Vector2[] a, Vector2[] b)
    {
        int n = a.Length, m = b.Length;
        if (n == 0 || m == 0) return float.PositiveInfinity;

        var cost = new float[n + 1, m + 1];
        for (int i = 1; i <= n; i++) cost[i, 0] = float.PositiveInfinity;
        for (int j = 1; j <= m; j++) cost[0, j] = float.PositiveInfinity;
        cost[0, 0] = 0f;

        for (int i = 1; i <= n; i++)
        {
            for (int j = 1; j <= m; j++)
            {
                float d = Vector2.Distance(a[i - 1], b[j - 1]);
                float prevMin = Mathf.Min(cost[i - 1, j], Mathf.Min(cost[i, j - 1], cost[i - 1, j - 1]));
                cost[i, j] = d + prevMin;
            }
        }

        return cost[n, m] / (n + m);
    }

    public static float PathLength(List<Vector2> points)
    {
        float len = 0f;
        for (int i = 1; i < points.Count; i++) len += Vector2.Distance(points[i - 1], points[i]);
        return len;
    }

    public static Vector2 Centroid(Vector2[] points)
    {
        if (points == null || points.Length == 0) return Vector2.zero;
        Vector2 sum = Vector2.zero;
        foreach (var p in points) sum += p;
        return sum / points.Length;
    }
}
