using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Captures mouse-drawn strokes inside a square drawing area in world space
/// (centered on this object's position, side length = boundsSize), and
/// reports points normalized to 0..1 so they line up with reference
/// CharacterStrokeData, which is stored in the same normalized space.
/// </summary>
public class StrokeInputRecorder : MonoBehaviour
{
    [Tooltip("World-space width/height of the square drawing area, centered on this object's position.")]
    public float boundsSize = 4f;

    public int mouseButton = 0;

    [Tooltip("Minimum normalized distance between recorded points, to avoid oversampling.")]
    public float minPointSpacing = 0.01f;

    public event Action OnStrokeStarted;
    public event Action<Vector2> OnPointAdded;
    public event Action<List<Vector2>> OnStrokeCompleted;

    private readonly List<Vector2> _current = new List<Vector2>();
    private bool _drawing;

    void Update()
    {
        if (Input.GetMouseButtonDown(mouseButton))
        {
            Vector2? p = ScreenToNormalized(Input.mousePosition);
            if (p.HasValue)
            {
                _drawing = true;
                _current.Clear();
                _current.Add(p.Value);
                OnStrokeStarted?.Invoke();
                OnPointAdded?.Invoke(p.Value);
            }
        }
        else if (_drawing && Input.GetMouseButton(mouseButton))
        {
            Vector2? p = ScreenToNormalized(Input.mousePosition);
            if (p.HasValue)
            {
                if (_current.Count == 0 || Vector2.Distance(_current[_current.Count - 1], p.Value) >= minPointSpacing)
                {
                    _current.Add(p.Value);
                    OnPointAdded?.Invoke(p.Value);
                }
            }
        }
        else if (_drawing && Input.GetMouseButtonUp(mouseButton))
        {
            _drawing = false;
            OnStrokeCompleted?.Invoke(new List<Vector2>(_current));
        }
    }

    private Vector2? ScreenToNormalized(Vector3 screenPos)
    {
        Camera cam = Camera.main;
        if (cam == null) return null;

        float distanceFromCamera = 0f - cam.transform.position.z;
        Vector3 world = cam.ScreenToWorldPoint(new Vector3(screenPos.x, screenPos.y, distanceFromCamera));

        float half = boundsSize * 0.5f;
        float nx = (world.x - (transform.position.x - half)) / boundsSize;
        float ny = (world.y - (transform.position.y - half)) / boundsSize;
        return new Vector2(Mathf.Clamp01(nx), Mathf.Clamp01(ny));
    }

    public Vector3 NormalizedToWorld(Vector2 normalized)
    {
        float half = boundsSize * 0.5f;
        float wx = transform.position.x - half + normalized.x * boundsSize;
        float wy = transform.position.y - half + normalized.y * boundsSize;
        return new Vector3(wx, wy, 0f);
    }
}
