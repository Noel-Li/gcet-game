using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Drives "Practice Mode": shows one reference stroke at a time, validates
/// the player's attempt against exactly that stroke, and advances on
/// success. This sidesteps the hard global stroke-order-alignment problem
/// entirely, since the game always knows which stroke index it's checking.
/// Works for any character loaded via CharacterDatabase — nothing here is
/// character-specific.
/// </summary>
[RequireComponent(typeof(StrokeInputRecorder))]
[RequireComponent(typeof(StrokeRenderer))]
public class CharacterWritingSession : MonoBehaviour
{
    public string targetCharacter = "十";
    public CharacterValidationSettings settings;
    public float feedbackFlashSeconds = 0.6f;

    private StrokeInputRecorder _recorder;
    private StrokeRenderer _renderer;
    private CharacterStrokeData _data;
    private int _currentStrokeIndex;
    private bool _busy;

    public string StatusMessage { get; private set; } = "";
    public int CurrentStrokeIndex => _currentStrokeIndex;
    public int TotalStrokes => _data != null && _data.strokes != null ? _data.strokes.Length : 0;
    public bool IsComplete { get; private set; }

    void Awake()
    {
        _recorder = GetComponent<StrokeInputRecorder>();
        _renderer = GetComponent<StrokeRenderer>();
        if (settings == null) settings = ScriptableObject.CreateInstance<CharacterValidationSettings>();
    }

    void OnEnable()
    {
        _recorder.OnStrokeCompleted += HandleStrokeCompleted;
        LoadCharacter(targetCharacter);
    }

    void OnDisable()
    {
        _recorder.OnStrokeCompleted -= HandleStrokeCompleted;
    }

    public void LoadCharacter(string character)
    {
        targetCharacter = character;
        _data = CharacterDatabase.Load(character);
        if (_data == null)
            _data = DemoCharacterData.Build(character);

        if (_data == null || _data.strokes == null || _data.strokes.Length == 0)
        {
            StatusMessage = $"No stroke data found for '{character}'.";
            _renderer.ClearGuides();
            return;
        }

        _currentStrokeIndex = 0;
        IsComplete = false;
        _renderer.ShowGuides(_data);
        _renderer.SetGuideState(0, GuideState.Active);
        StatusMessage = $"Draw stroke 1 of {_data.strokes.Length} for {character}";
    }

    private void HandleStrokeCompleted(List<Vector2> points)
    {
        if (_busy || _data == null || IsComplete) return;

        var reference = _data.strokes[_currentStrokeIndex];
        var result = StrokeValidator.ValidateStroke(points, reference, settings);

        if (result.pass)
        {
            _renderer.SetGuideState(_currentStrokeIndex, GuideState.Pass);
            _currentStrokeIndex++;

            if (_currentStrokeIndex >= _data.strokes.Length)
            {
                IsComplete = true;
                StatusMessage = $"Complete! You wrote {targetCharacter} correctly.";
            }
            else
            {
                _renderer.SetGuideState(_currentStrokeIndex, GuideState.Active);
                StatusMessage = $"Correct! Draw stroke {_currentStrokeIndex + 1} of {_data.strokes.Length}";
            }
        }
        else
        {
            StatusMessage = result.message;
            StartCoroutine(FlashFail(_currentStrokeIndex));
        }

        _renderer.ClearPlayerLine();
    }

    private IEnumerator FlashFail(int index)
    {
        _busy = true;
        _renderer.SetGuideState(index, GuideState.Fail);
        yield return new WaitForSeconds(feedbackFlashSeconds);
        _renderer.SetGuideState(index, GuideState.Active);
        _busy = false;
    }
}
