using System.Collections.Generic;
using UnityEngine;

public enum GuideState { Idle, Active, Pass, Fail }

/// <summary>
/// Visualizes the drawing bounds, the reference character's guide strokes,
/// and the player's live stroke, all via LineRenderers created at runtime
/// (no prefabs or material assets required — uses the built-in Sprites/Default
/// shader so it works in a bare project with no extra setup).
/// </summary>
[RequireComponent(typeof(StrokeInputRecorder))]
public class StrokeRenderer : MonoBehaviour
{
    public Color guideColor = new Color(0.6f, 0.6f, 0.6f, 0.5f);
    public Color guideActiveColor = new Color(0.2f, 0.4f, 1f, 0.8f);
    public Color guidePassColor = new Color(0.2f, 0.8f, 0.2f, 0.9f);
    public Color guideFailColor = new Color(0.9f, 0.2f, 0.2f, 0.9f);
    public Color playerColor = Color.black;
    public Color boundsColor = new Color(0f, 0f, 0f, 0.3f);
    public float lineWidth = 0.05f;

    private StrokeInputRecorder _recorder;
    private LineRenderer _playerLine;
    private LineRenderer _boundsLine;
    private readonly List<LineRenderer> _guideLines = new List<LineRenderer>();
    private readonly List<Vector2> _livePoints = new List<Vector2>();

    void Awake()
    {
        _recorder = GetComponent<StrokeInputRecorder>();
        _playerLine = CreateLine("PlayerStrokeLine", playerColor, lineWidth, 10);
        _boundsLine = CreateLine("BoundsOutline", boundsColor, lineWidth * 0.5f, 1);
        DrawBoundsOutline();
    }

    void OnEnable()
    {
        if (_recorder == null) _recorder = GetComponent<StrokeInputRecorder>();
        _recorder.OnStrokeStarted += HandleStrokeStarted;
        _recorder.OnPointAdded += HandlePointAdded;
    }

    void OnDisable()
    {
        if (_recorder == null) return;
        _recorder.OnStrokeStarted -= HandleStrokeStarted;
        _recorder.OnPointAdded -= HandlePointAdded;
    }

    private LineRenderer CreateLine(string goName, Color color, float width, int sortOrder)
    {
        var go = new GameObject(goName);
        go.transform.SetParent(transform, false);
        var lr = go.AddComponent<LineRenderer>();
        var mat = new Material(Shader.Find("Sprites/Default"));
        mat.color = color;
        lr.material = mat;
        lr.startColor = color;
        lr.endColor = color;
        lr.startWidth = width;
        lr.endWidth = width;
        lr.useWorldSpace = true;
        lr.positionCount = 0;
        lr.sortingOrder = sortOrder;
        lr.numCapVertices = 4;
        lr.numCornerVertices = 4;
        return lr;
    }

    private void DrawBoundsOutline()
    {
        float half = _recorder.boundsSize * 0.5f;
        Vector3 c = transform.position;
        var corners = new[]
        {
            c + new Vector3(-half, -half, 0),
            c + new Vector3(half, -half, 0),
            c + new Vector3(half, half, 0),
            c + new Vector3(-half, half, 0),
            c + new Vector3(-half, -half, 0)
        };
        _boundsLine.positionCount = corners.Length;
        _boundsLine.SetPositions(corners);
    }

    private void HandleStrokeStarted()
    {
        _livePoints.Clear();
        _playerLine.positionCount = 0;
    }

    private void HandlePointAdded(Vector2 normalized)
    {
        _livePoints.Add(normalized);
        _playerLine.positionCount = _livePoints.Count;
        for (int i = 0; i < _livePoints.Count; i++)
            _playerLine.SetPosition(i, _recorder.NormalizedToWorld(_livePoints[i]));
    }

    public void ClearPlayerLine()
    {
        _livePoints.Clear();
        _playerLine.positionCount = 0;
    }

    public void ShowGuides(CharacterStrokeData data)
    {
        ClearGuides();
        if (data == null || data.strokes == null) return;

        foreach (var stroke in data.strokes)
        {
            var lr = CreateLine("Guide", guideColor, lineWidth * 0.8f, 2);
            lr.positionCount = stroke.medianPoints.Length;
            for (int i = 0; i < stroke.medianPoints.Length; i++)
                lr.SetPosition(i, _recorder.NormalizedToWorld(stroke.medianPoints[i]));
            _guideLines.Add(lr);
        }
    }

    public void ClearGuides()
    {
        foreach (var lr in _guideLines)
            if (lr != null) Destroy(lr.gameObject);
        _guideLines.Clear();
    }

    public void SetGuideState(int strokeIndex, GuideState state)
    {
        if (strokeIndex < 0 || strokeIndex >= _guideLines.Count) return;
        var lr = _guideLines[strokeIndex];
        Color c = state switch
        {
            GuideState.Active => guideActiveColor,
            GuideState.Pass => guidePassColor,
            GuideState.Fail => guideFailColor,
            _ => guideColor
        };
        lr.startColor = c;
        lr.endColor = c;
        lr.material.color = c;
    }
}
