using UnityEngine;

/// <summary>
/// Loads CharacterStrokeData assets by character at runtime, from
/// Resources/CharacterData/{unicode hex}.asset. New characters can be added
/// to the project (via HanziStrokeImporter or SampleCharacterCreator)
/// without any code changes here.
/// </summary>
public static class CharacterDatabase
{
    public static CharacterStrokeData Load(string character)
    {
        if (string.IsNullOrEmpty(character)) return null;
        int codepoint = char.ConvertToUtf32(character, 0);
        string hex = codepoint.ToString("X4");
        return Resources.Load<CharacterStrokeData>($"CharacterData/{hex}");
    }
}
