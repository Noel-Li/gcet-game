using UnityEngine;

/// <summary>
/// Hand-authored stroke data for three simple characters (一, 十, 人), used
/// two ways: (1) as a zero-setup runtime fallback so the demo scene works
/// immediately with no asset import step, and (2) by the
/// SampleCharacterCreator editor tool to persist them as real
/// CharacterStrokeData assets. This is only meant as a bootstrap/demo — real
/// content should come from HanziStrokeImporter (see design doc §2).
/// </summary>
public static class DemoCharacterData
{
    public static CharacterStrokeData Build(string character)
    {
        switch (character)
        {
            case "一": return BuildYi();
            case "十": return BuildShi();
            case "人": return BuildRen();
            default: return null;
        }
    }

    private static CharacterStrokeData BuildYi()
    {
        var data = ScriptableObject.CreateInstance<CharacterStrokeData>();
        data.character = "一";
        data.unicodeCodepoint = 0x4E00;
        data.sourceType = "generated";
        data.strokes = new StrokeData[]
        {
            new StrokeData { medianPoints = new[] { new Vector2(0.15f, 0.5f), new Vector2(0.85f, 0.5f) } }
        };
        return data;
    }

    private static CharacterStrokeData BuildShi()
    {
        var data = ScriptableObject.CreateInstance<CharacterStrokeData>();
        data.character = "十";
        data.unicodeCodepoint = 0x5341;
        data.sourceType = "generated";
        data.strokes = new StrokeData[]
        {
            new StrokeData { medianPoints = new[] { new Vector2(0.15f, 0.55f), new Vector2(0.85f, 0.55f) } },
            new StrokeData { medianPoints = new[] { new Vector2(0.5f, 0.9f), new Vector2(0.5f, 0.1f) } }
        };
        return data;
    }

    private static CharacterStrokeData BuildRen()
    {
        var data = ScriptableObject.CreateInstance<CharacterStrokeData>();
        data.character = "人";
        data.unicodeCodepoint = 0x4EBA;
        data.sourceType = "generated";
        data.strokes = new StrokeData[]
        {
            new StrokeData { medianPoints = new[] { new Vector2(0.55f, 0.9f), new Vector2(0.2f, 0.1f) } },
            new StrokeData { medianPoints = new[] { new Vector2(0.5f, 0.6f), new Vector2(0.8f, 0.1f) } }
        };
        return data;
    }
}
