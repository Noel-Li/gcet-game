using UnityEditor;
using UnityEngine;

/// <summary>
/// Builds the demo scene hierarchy (Main Camera + GameController with all
/// four gameplay components) purely through Unity's own APIs. Run this in
/// any empty scene as a guaranteed-correct alternative to opening the
/// hand-authored HanziWriterDemo.unity file directly.
/// </summary>
public static class HanziSceneBuilder
{
    [MenuItem("Tools/Hanzi Writer/Build Demo Scene In Current Scene")]
    public static void Build()
    {
        Camera cam = Camera.main;
        if (cam == null)
        {
            var camGo = new GameObject("Main Camera");
            camGo.tag = "MainCamera";
            cam = camGo.AddComponent<Camera>();
            camGo.AddComponent<AudioListener>();
        }
        cam.orthographic = true;
        cam.orthographicSize = 5f;
        cam.transform.position = new Vector3(0f, 0f, -10f);
        cam.backgroundColor = Color.white;
        cam.clearFlags = CameraClearFlags.SolidColor;

        var existing = GameObject.Find("GameController");
        if (existing != null) Object.DestroyImmediate(existing);

        var go = new GameObject("GameController");
        go.transform.position = Vector3.zero;

        var recorder = go.AddComponent<StrokeInputRecorder>();
        recorder.boundsSize = 4f;
        go.AddComponent<StrokeRenderer>();
        go.AddComponent<CharacterWritingSession>();
        go.AddComponent<CharacterWritingUI>();

        Debug.Log("Hanzi Writer demo scene objects created. Press Play to test — draw inside the square, following the gray guide stroke.");
    }
}
