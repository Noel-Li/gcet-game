using System.IO;
using UnityEditor;
using UnityEngine;

/// <summary>
/// The reusable pipeline tool: point it at a JSON file (see
/// SampleData/sample_characters.json for the schema) and it creates or
/// updates one CharacterStrokeData asset per entry under
/// Assets/Resources/CharacterData/. Re-running it for the same character is
/// safe (it overwrites in place), and it works for one character or
/// thousands in the same file — nothing here is per-character code.
/// </summary>
public static class HanziStrokeImporter
{
    [MenuItem("Tools/Hanzi Writer/Import Characters From JSON...")]
    public static void ImportFromJson()
    {
        string path = EditorUtility.OpenFilePanel("Select character stroke JSON", Application.dataPath, "json");
        if (string.IsNullOrEmpty(path)) return;

        string json = File.ReadAllText(path);
        var wrapper = JsonUtility.FromJson<CharacterJsonWrapper>(json);
        if (wrapper == null || wrapper.characters == null)
        {
            Debug.LogError("HanziStrokeImporter: could not parse JSON — expected a top-level 'characters' array. See SampleData/sample_characters.json for the expected schema.");
            return;
        }

        const string folder = "Assets/Resources/CharacterData";
        EnsureFolder("Assets", "Resources");
        EnsureFolder("Assets/Resources", "CharacterData");

        int imported = 0;
        foreach (var entry in wrapper.characters)
        {
            if (string.IsNullOrEmpty(entry.character) || entry.strokes == null)
            {
                Debug.LogWarning("HanziStrokeImporter: skipping an entry with missing character or strokes.");
                continue;
            }

            int codepoint = char.ConvertToUtf32(entry.character, 0);
            string hex = codepoint.ToString("X4");
            string assetPath = $"{folder}/{hex}.asset";

            var data = AssetDatabase.LoadAssetAtPath<CharacterStrokeData>(assetPath);
            bool isNew = data == null;
            if (isNew) data = ScriptableObject.CreateInstance<CharacterStrokeData>();

            data.character = entry.character;
            data.unicodeCodepoint = codepoint;
            data.sourceType = "dataset";
            data.strokes = new StrokeData[entry.strokes.Length];
            for (int i = 0; i < entry.strokes.Length; i++)
            {
                var pts = entry.strokes[i].points;
                var median = new Vector2[pts.Length];
                for (int j = 0; j < pts.Length; j++) median[j] = new Vector2(pts[j].x, pts[j].y);
                data.strokes[i] = new StrokeData { medianPoints = median };
            }

            if (isNew) AssetDatabase.CreateAsset(data, assetPath);
            else EditorUtility.SetDirty(data);
            imported++;
        }

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Debug.Log($"HanziStrokeImporter: imported/updated {imported} character(s) into {folder}");
    }

    private static void EnsureFolder(string parent, string name)
    {
        if (!AssetDatabase.IsValidFolder($"{parent}/{name}"))
            AssetDatabase.CreateFolder(parent, name);
    }

    [System.Serializable] private class CharacterJsonWrapper { public CharacterJsonEntry[] characters; }
    [System.Serializable] private class CharacterJsonEntry { public string character; public string unicode; public StrokeJsonEntry[] strokes; }
    [System.Serializable] private class StrokeJsonEntry { public PointJson[] points; }
    [System.Serializable] private class PointJson { public float x; public float y; }
}
