using UnityEditor;
using UnityEngine;

/// <summary>
/// Convenience tool for the demo: saves 一, 十, 人 as real assets under
/// Resources/CharacterData/, so you can see how imported characters look on
/// disk and confirm CharacterDatabase.Load resolves them. Not required for
/// the scene to run — CharacterWritingSession falls back to the same data
/// in-memory if these assets don't exist.
/// </summary>
public static class SampleCharacterCreator
{
    [MenuItem("Tools/Hanzi Writer/Create Sample Characters (十, 一, 人)")]
    public static void CreateSamples()
    {
        const string folder = "Assets/Resources/CharacterData";
        if (!AssetDatabase.IsValidFolder("Assets/Resources"))
            AssetDatabase.CreateFolder("Assets", "Resources");
        if (!AssetDatabase.IsValidFolder(folder))
            AssetDatabase.CreateFolder("Assets/Resources", "CharacterData");

        string[] chars = { "一", "十", "人" };
        foreach (var ch in chars)
        {
            var data = DemoCharacterData.Build(ch);
            string hex = data.unicodeCodepoint.ToString("X4");
            string assetPath = $"{folder}/{hex}.asset";

            var existing = AssetDatabase.LoadAssetAtPath<CharacterStrokeData>(assetPath);
            if (existing != null) AssetDatabase.DeleteAsset(assetPath);

            AssetDatabase.CreateAsset(data, assetPath);
        }

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Debug.Log("SampleCharacterCreator: created 一, 十, 人 under " + folder);
    }
}
